/*
* Appendix A does not contain progressively built code.
* To see the code variations in this Appendix,
* use the code browser.
*
*/