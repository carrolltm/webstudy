$(document).ready(function() {
  $('#books').cycle();
});
