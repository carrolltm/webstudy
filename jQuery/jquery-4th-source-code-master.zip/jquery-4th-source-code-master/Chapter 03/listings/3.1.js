$(document).ready(function() {
  $('#switcher-large').on('click', function() {
    $('body').addClass('large');
  });
});
