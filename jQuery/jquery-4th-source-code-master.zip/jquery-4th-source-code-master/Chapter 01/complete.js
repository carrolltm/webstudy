$(document).ready(function() {
  $('div.poem-stanza').addClass('highlight');
});
