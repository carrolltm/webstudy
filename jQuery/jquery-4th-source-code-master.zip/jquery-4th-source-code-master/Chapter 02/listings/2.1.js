$(document).ready(function() {
  $('#selected-plays > li').addClass('horizontal');
});
