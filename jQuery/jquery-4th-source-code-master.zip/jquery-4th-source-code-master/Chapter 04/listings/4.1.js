$(document).ready(function() {
  $('#switcher-large').click(function() {
  });
});
